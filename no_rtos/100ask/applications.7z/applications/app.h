/*
 * app.h
 *
 *  Created on: 2023年3月31日
 *      Author: slhuan
 */

#include "hal_data.h"

#ifndef APP_H_
#define APP_H_

void app_lvgl(void);

#endif
